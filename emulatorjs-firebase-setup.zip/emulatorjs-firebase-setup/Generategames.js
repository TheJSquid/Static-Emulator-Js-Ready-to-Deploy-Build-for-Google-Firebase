const fs = require('fs');
const path = require('path');

const ROMS_DIR = path.join(__dirname, 'public', 'roms');
const OUTPUT_JSON = path.join(__dirname, 'public', 'games.json');

function detectCore(filepath) {
  const ext = path.extname(filepath).toLowerCase();
  if (ext === '.gba') return 'gba';
  if (ext === '.nds') return 'nds';
  if (ext === '.gb' || ext === '.gbc') return 'gb';
  if (ext === '.nes') return 'nes';
  if (ext === '.sfc' || ext === '.smc') return 'snes';
  if (ext === '.z64') return 'n64';
  if (ext === '.md') return 'megadrive';
  if (ext === '.iso') return filepath.toLowerCase().includes(`${path.sep}psp${path.sep}`) ? 'psp' : 'psx';
  return 'unknown';
}

function scanRoms(dir, baseDir = ROMS_DIR) {
  let games = [];
  fs.readdirSync(dir).forEach(file => {
    const fullPath = path.join(dir, file);
    const stat = fs.statSync(fullPath);
    if (stat.isDirectory()) {
      games = games.concat(scanRoms(fullPath, baseDir));
    } else {
      const core = detectCore(fullPath);
      if (core !== 'unknown') {
        games.push({
          name: path.relative(baseDir, fullPath),
          core: core,
          url: 'roms/' + path.relative(baseDir, fullPath).replace(/\\/g, '/')
        });
      }
    }
  });
  return games;
}

const games = scanRoms(ROMS_DIR);
fs.writeFileSync(OUTPUT_JSON, JSON.stringify(games, null, 2));
console.log(`✅ games.json written with ${games.length} games.`);
