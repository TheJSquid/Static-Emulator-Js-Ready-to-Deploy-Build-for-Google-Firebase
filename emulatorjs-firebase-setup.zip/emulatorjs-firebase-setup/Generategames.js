const fs = require('fs');
const path = require('path');

// Adjusted for your Firebase /public/roms directory
const ROMS_DIR = path.join(__dirname, 'public', 'roms');
const OUTPUT_JSON = path.join(__dirname, 'public', 'games.json');

function detectCore(filepath) {
  const ext = path.extname(filepath).toLowerCase();

  switch (ext) {
    // Game Boy / Game Boy Color
    case '.gb':
    case '.gbc': return 'gb';

    // Game Boy Advance
    case '.gba': return 'gba';

    // Nintendo DS
    case '.nds': return 'nds';

    // NES / Famicom
    case '.nes': return 'nes';

    // SNES
    case '.sfc':
    case '.smc': return 'snes';

    // Nintendo 64
    case '.z64':
    case '.n64':
    case '.v64': return 'n64';

    // Sega Mega Drive / Genesis
    case '.md':
    case '.bin':
    case '.gen':
    case '.smd': return 'segaMD';

    // PlayStation 1 & PSP
    case '.iso':
    case '.cso':
    case '.pbp':
      if (filepath.toLowerCase().includes(`${path.sep}psp${path.sep}`)) {
        return 'psp';
      } else {
        return 'psx';
      }

    // PlayStation 1 multi-track images
    case '.cue':
      if (filepath.toLowerCase().includes(`${path.sep}psp${path.sep}`)) {
        return 'psp';
      } else {
        return 'psx';
      }

    // Arcade (MAME)
    case '.zip': return 'arcade';

    default: return 'unknown';
  }
}

function scanRoms(dir, baseUrl = 'roms') {
  const files = fs.readdirSync(dir);
  const games = [];

  files.forEach(file => {
    const fullPath = path.join(dir, file);
    const stat = fs.statSync(fullPath);

    if (stat.isFile()) {
      const core = detectCore(fullPath);
      if (core !== 'unknown') {
        games.push({
          name: path.basename(file, path.extname(file)),
          core: core,
          url: `${baseUrl}/${file}`
        });
      }
    } else if (stat.isDirectory()) {
      const subGames = scanRoms(fullPath, `${baseUrl}/${file}`);
      games.push(...subGames);
    }
  });

  return games;
}

const games = scanRoms(ROMS_DIR);

fs.writeFileSync(OUTPUT_JSON, JSON.stringify(games, null, 2), 'utf8');

console.log(`games.json written with ${games.length} games.`);
