const fs = require('fs');
const path = require('path');

const ROMS_DIR = path.join(__dirname, 'public', 'roms');
const OUTPUT_FILE = path.join(__dirname, 'public', 'games.json');

// Supported ROM extensions (lowercase)
const SUPPORTED_EXTS = ['.gba', '.nds', '.gb', '.gbc', '.nes', '.sfc', '.smc', '.z64', '.md', '.iso'];

function scanFolder(folder) {
  let games = [];

  const items = fs.readdirSync(folder, { withFileTypes: true });

  for (const item of items) {
    const fullPath = path.join(folder, item.name);

    if (item.isDirectory()) {
      console.log(`Entering directory: ${fullPath}`);
      // Recursively scan subfolders
      games = games.concat(scanFolder(fullPath));
    } else {
      const ext = path.extname(item.name).toLowerCase();
      console.log(`Checking file: ${fullPath}`);

      if (SUPPORTED_EXTS.includes(ext)) {
        // Create game entry with relative URL from 'public' folder
        const relativePath = path.relative(path.join(__dirname, 'public'), fullPath).replace(/\\/g, '/');

        // Derive a nice game name from file name (remove extension and replace underscores)
        const name = path.basename(item.name, ext).replace(/_/g, ' ');

        // Guess core from extension with EmulatorJS core names
        let core = 'unknown';
        switch (ext) {
          case '.gba': core = 'gba'; break;
          case '.nds': core = 'nds'; break;
          case '.gb':
          case '.gbc': core = 'gb'; break;
          case '.nes': core = 'nes'; break;
          case '.sfc':
          case '.smc': core = 'snes'; break;
          case '.z64': core = 'n64'; break;
          case '.md': core = 'megadrive'; break;
          case '.iso': core = 'psx'; break;
        }

        console.log(`Adding game: ${name} (core: ${core})`);
        games.push({
          name,
          core,
          url: relativePath,
        });
      } else {
        console.log(`Skipped unsupported file: ${item.name}`);
      }
    }
  }

  return games;
}

try {
  const allGames = scanFolder(ROMS_DIR);

  fs.writeFileSync(OUTPUT_FILE, JSON.stringify(allGames, null, 2));
  console.log(`✅ Generated games.json with ${allGames.length} games.`);
} catch (error) {
  console.error('❌ Error generating games.json:', error);
}
